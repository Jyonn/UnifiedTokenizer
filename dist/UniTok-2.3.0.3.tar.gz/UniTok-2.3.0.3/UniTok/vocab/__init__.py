from .vocab import Vocab
from .depot import VocabDepot

__all__ = [
    Vocab, VocabDepot
]
